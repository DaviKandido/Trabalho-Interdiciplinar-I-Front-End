OBS: O replit geralmente apresenta problemas com os 
arquivos, melhor testar localmente, caso tente visualizar 
pelo replit recomendo copiar html e jogar na barra de 
pesquisa do replit, caso continue dando erro, 
teste localmente.

-Funcionamento Agenda:
Para incluir uma tarefa é necessario selecionar um dia 
antes, caso tente incluir uma terafa de primeira, ou seja
sem clicar em um dos dias antes, a terfa não será incluida

-Funcionamento Aba de inclusão de Plataformas:
Uma aba que ficará abaixo do calendário servindo para 
a inclusão de plataformas, ou seja de ferramentas de 
produtividade ao projeto, possibilitando ao usuário 
incluir plataformas que serão usadas durante o 
gerenciamento de seu projeto, click em incluir mais 
plataformas para abri-la.


# Daigaku Connect

![](https://github.com/ICEI-PUC-Minas-PMGCC-TI/daigaku-connect/blob/main/source/logo.png?raw=true)

A libre software project that aims to provide free (as in freedom), safe and efficient communication for project management within the university environment.

[![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html) 

## Authors

- [Davi Cândido de Almeida](https://github.com/DaviKandido)
- [Gabriel Anderson](https://github.com/gonafritas)
- [Harper Moreira Mascarenhas](https://github.com/harperbolic)


## Responsibles professors

* Carlos Alberto Marques Pietrobon
* Hayala Nepomuceno Curto
